//
//  ViewController.swift
//  lightApp
//
//  Created by 維衣 on 2022/8/2.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var labels: [UILabel]!
    @IBOutlet weak var numString: UITextField!
    @IBOutlet weak var colorBtn: UIButton!
    @IBOutlet weak var hiddenView: UIView!
    @IBOutlet var colorButtons: [UIButton]!
    
    var saveInt:Int = 0
    var saveColorStr = ""
    var ansText = ""
    var n:Int = 0
//    var numberskey:[Numerology] = []
//    var numbersvalue:[Numerology] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        hiddenView.isHidden = true
        
        for i in 0...colorButtons.count - 1{
//            colorButtons[i].titleLabel!.text = numerologys[i].numerologyValue
            colorButtons[i].setTitle("\(numerologys[i].numerologyValue)", for: .normal)
        
//            numbersKey = numerologys[i].numerologyKey
//            numbersValue = numerologys[i].numerologyValue
            
        }
    }
    
    
    
    @IBAction func showColor(_ sender: UIButton) {
        
        
        //*
        //改三元運算式
        hiddenView.isHidden = false
        
        if numString.text!.isEmpty == true {
            labels[2].text = "還沒輸入數字"
        }else{
            labels[2].text = ""
        }
        //*

        
    }
    
    @IBAction func inputColor(_ sender: UIButton) {
        hiddenView.isHidden = false
        
        saveInt = Int(numString.text!) ?? 0
        saveColorStr = sender.titleLabel!.text!
        
        labels[2].text = printAns(saveInt, saveColorStr)
        print("labels[2].text == \(labels[2].text!)")
//        print("**saveColorStr == \(saveColorStr)")
//        print("**saveInt == \(saveInt)")
//        print("**saveColorStr == \(saveColorStr)")
        hiddenView.isHidden = true
    }
    
    

    func printAns( _ saveInt: Int, _ saveColorStr: String) -> String {
            
        for i in 0...8{
            let ansText = (numerologys[i].numerologyKey == saveInt && numerologys[i].numerologyValue == saveColorStr) ? "答對了!!" : "答錯了!!"
            print("**ansText == \(numerologys[i].numerologyKey)")
        print("**numbersKey == \(numerologys[i].numerologyKey)")
        print("**numerologyValue == \(numerologys[i].numerologyValue)")
            
        }
        
        
        
        print("ansText == \(ansText)")
        return ansText ?? "**bug"
    }
}


